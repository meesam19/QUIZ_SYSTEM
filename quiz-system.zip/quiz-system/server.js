// =============================================
// server.js - The HEART of our application
// This is the main file that starts everything
// =============================================

// Load environment variables FIRST (before anything else)
require('dotenv').config();

// ---- IMPORT LIBRARIES ----
const express = require('express');        // Web framework
const session = require('express-session'); // For login sessions
const path = require('path');              // For file paths

// ---- IMPORT OUR ROUTE FILES ----
// Routes handle different URLs (like /login, /dashboard, etc.)
const authRoutes = require('./routes/auth');
const adminRoutes = require('./routes/admin');
const studentRoutes = require('./routes/student');

// ---- CREATE THE APP ----
const app = express();
const PORT = process.env.PORT || 3000;

// =============================================
// MIDDLEWARE SETUP
// Middleware runs on EVERY request before your routes
// Think of it as security checks at a building entrance
// =============================================

// 1. Parse form data (so we can read form submissions)
app.use(express.urlencoded({ extended: true }));

// 2. Parse JSON data (for API-like requests)
app.use(express.json());

// 3. Serve static files (CSS, JS, images) from the 'public' folder
app.use(express.static(path.join(__dirname, 'public')));

// 4. Set up sessions (this remembers who is logged in)
app.use(session({
    secret: process.env.SESSION_SECRET,  // Secret key to encrypt session data
    resave: false,                        // Don't save session if nothing changed
    saveUninitialized: false,             // Don't create session for non-logged-in users
    cookie: { 
        maxAge: 1000 * 60 * 60 * 2       // Session lasts 2 hours (in milliseconds)
    }
}));

// 5. Set EJS as our template engine
// EJS lets us mix HTML with JavaScript to show dynamic data
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// =============================================
// ROUTES - Which code handles which URL
// =============================================

// Home page - redirect to login
app.get('/', (req, res) => {
    // If already logged in, redirect to their dashboard
    if (req.session.user) {
        if (req.session.user.role === 'admin') {
            return res.redirect('/admin/dashboard');
        } else {
            return res.redirect('/student/dashboard');
        }
    }
    // Otherwise redirect to login page
    res.redirect('/login');
});

// Authentication routes (login, register, logout)
app.use('/', authRoutes);

// Admin routes (create quiz, view results, etc.)
app.use('/admin', adminRoutes);

// Student routes (attempt quiz, view results, etc.)
app.use('/student', studentRoutes);

// ---- 404 PAGE (when URL is not found) ----
app.use((req, res) => {
    res.status(404).send(`
        <html>
        <body style="font-family: Arial; text-align: center; margin-top: 100px;">
            <h1>404 - Page Not Found</h1>
            <p>The page you're looking for doesn't exist.</p>
            <a href="/">Go Home</a>
        </body>
        </html>
    `);
});

// ---- START THE SERVER ----
app.listen(PORT, () => {
    console.log('=============================================');
    console.log(`✅ Server is running!`);
    console.log(`🌐 Open your browser and go to:`);
    console.log(`   http://localhost:${PORT}`);
    console.log('=============================================');
    console.log('📧 Default admin login:');
    console.log('   Email: admin@quiz.com');
    console.log('   Password: admin123');
    console.log('=============================================');
});
