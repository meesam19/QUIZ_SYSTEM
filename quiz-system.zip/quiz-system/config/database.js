// =============================================
// config/database.js
// This file connects our app to MySQL database
// =============================================

// Load environment variables from .env file
require('dotenv').config();

// Import mysql2 library
const mysql = require('mysql2');

// Create a "connection pool"
// A pool manages multiple database connections efficiently
// Think of it like a pool of phone lines - reused instead of creating new ones each time
const pool = mysql.createPool({
    host: process.env.DB_HOST,         // Usually 'localhost'
    user: process.env.DB_USER,         // Your MySQL username
    password: process.env.DB_PASSWORD, // Your MySQL password
    database: process.env.DB_NAME,     // Database name: quiz_system
    waitForConnections: true,
    connectionLimit: 10,               // Max 10 connections at once
    queueLimit: 0
});

// ".promise()" lets us use async/await instead of callbacks
// This makes code cleaner and easier to read
const db = pool.promise();

// Export so other files can use this connection
module.exports = db;
