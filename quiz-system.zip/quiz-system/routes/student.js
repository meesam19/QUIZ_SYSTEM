// =============================================
// routes/student.js
// All Student pages and actions
// =============================================

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isLoggedIn, isStudent } = require('../middleware/auth');

// Apply middleware to ALL student routes
router.use(isLoggedIn, isStudent);

// =============================================
// GET /student/dashboard - Student Home Page
// =============================================
router.get('/dashboard', async (req, res) => {
    try {
        // Get all available quizzes
        const [quizzes] = await db.query(`
            SELECT q.*, COUNT(qs.id) as question_count
            FROM quizzes q
            LEFT JOIN questions qs ON q.id = qs.quiz_id
            GROUP BY q.id
            ORDER BY q.created_at DESC
        `);

        // Get this student's recent results (last 5)
        const [myResults] = await db.query(`
            SELECT r.*, q.title as quiz_title
            FROM results r
            JOIN quizzes q ON r.quiz_id = q.id
            WHERE r.student_id = ?
            ORDER BY r.attempted_at DESC
            LIMIT 5
        `, [req.session.user.id]);

        res.render('student/dashboard', {
            user: req.session.user,
            quizzes,
            myResults
        });

    } catch (error) {
        console.error('Student dashboard error:', error);
        res.send('Error loading dashboard');
    }
});

// =============================================
// GET /student/attempt/:quizId - Show quiz questions
// =============================================
router.get('/attempt/:quizId', async (req, res) => {
    const quizId = req.params.quizId;

    try {
        // Get quiz info
        const [quizzes] = await db.query(
            'SELECT * FROM quizzes WHERE id = ?', 
            [quizId]
        );

        if (quizzes.length === 0) {
            return res.send('Quiz not found!');
        }

        // Get all questions for this quiz
        const [questions] = await db.query(
            'SELECT * FROM questions WHERE quiz_id = ?', 
            [quizId]
        );

        if (questions.length === 0) {
            return res.send('This quiz has no questions yet. Check back later!');
        }

        res.render('student/attempt-quiz', {
            user: req.session.user,
            quiz: quizzes[0],
            questions
        });

    } catch (error) {
        console.error('Attempt quiz error:', error);
        res.send('Error loading quiz');
    }
});

// =============================================
// POST /student/submit/:quizId - Submit quiz answers
// =============================================
router.post('/submit/:quizId', async (req, res) => {
    const quizId = req.params.quizId;
    const answers = req.body; // Object like { "1": "a", "2": "c", "3": "b" }

    try {
        // Get all questions with correct answers
        const [questions] = await db.query(
            'SELECT * FROM questions WHERE quiz_id = ?', 
            [quizId]
        );

        if (questions.length === 0) {
            return res.send('Quiz not found!');
        }

        // ---- CALCULATE SCORE ----
        let score = 0;
        const questionResults = []; // Store each question's result

        questions.forEach(question => {
            const studentAnswer = answers[question.id]; // Student's answer for this question
            const isCorrect = studentAnswer === question.correct_answer;
            
            if (isCorrect) score++; // Increment score if correct

            questionResults.push({
                question_id: question.id,
                selected: studentAnswer || null,
                correct: question.correct_answer,
                isCorrect,
                question_text: question.question_text,
                option_a: question.option_a,
                option_b: question.option_b,
                option_c: question.option_c,
                option_d: question.option_d
            });
        });

        const total = questions.length;
        const percentage = ((score / total) * 100).toFixed(2);

        // ---- SAVE RESULT TO DATABASE ----
        const [resultRow] = await db.query(
            'INSERT INTO results (student_id, quiz_id, score, total, percentage) VALUES (?, ?, ?, ?, ?)',
            [req.session.user.id, quizId, score, total, percentage]
        );

        const resultId = resultRow.insertId;

        // ---- SAVE EACH ANSWER ----
        for (const qr of questionResults) {
            await db.query(
                'INSERT INTO student_answers (result_id, question_id, selected_answer, is_correct) VALUES (?, ?, ?, ?)',
                [resultId, qr.question_id, qr.selected, qr.isCorrect]
            );
        }

        // Redirect to results page
        res.redirect(`/student/results/${resultId}`);

    } catch (error) {
        console.error('Submit quiz error:', error);
        res.send('Error submitting quiz. Please try again.');
    }
});

// =============================================
// GET /student/results/:resultId - Show quiz results
// =============================================
router.get('/results/:resultId', async (req, res) => {
    try {
        // Get the result
        const [results] = await db.query(`
            SELECT r.*, q.title as quiz_title
            FROM results r
            JOIN quizzes q ON r.quiz_id = q.id
            WHERE r.id = ? AND r.student_id = ?
        `, [req.params.resultId, req.session.user.id]);

        if (results.length === 0) {
            return res.send('Result not found!');
        }

        // Get the detailed answers with questions
        const [answers] = await db.query(`
            SELECT sa.*, q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_answer
            FROM student_answers sa
            JOIN questions q ON sa.question_id = q.id
            WHERE sa.result_id = ?
        `, [req.params.resultId]);

        res.render('student/results', {
            user: req.session.user,
            result: results[0],
            answers
        });

    } catch (error) {
        console.error('View results error:', error);
        res.send('Error loading results');
    }
});

// =============================================
// GET /student/my-results - View all my results
// =============================================
router.get('/my-results', async (req, res) => {
    try {
        const [results] = await db.query(`
            SELECT r.*, q.title as quiz_title
            FROM results r
            JOIN quizzes q ON r.quiz_id = q.id
            WHERE r.student_id = ?
            ORDER BY r.attempted_at DESC
        `, [req.session.user.id]);

        res.render('student/my-results', {
            user: req.session.user,
            results
        });

    } catch (error) {
        console.error('My results error:', error);
        res.send('Error loading results');
    }
});

module.exports = router;
