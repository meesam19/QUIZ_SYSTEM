// =============================================
// routes/admin.js
// All Admin pages and actions
// =============================================

const express = require('express');
const router = express.Router();
const db = require('../config/database');
const { isLoggedIn, isAdmin } = require('../middleware/auth');

// Apply middleware to ALL admin routes
// isLoggedIn runs first, then isAdmin
// If either fails, the route never runs
router.use(isLoggedIn, isAdmin);

// =============================================
// GET /admin/dashboard - Admin Home Page
// =============================================
router.get('/dashboard', async (req, res) => {
    try {
        // Get total number of quizzes
        const [quizCount] = await db.query('SELECT COUNT(*) as total FROM quizzes');
        
        // Get total number of students
        const [studentCount] = await db.query(
            'SELECT COUNT(*) as total FROM users WHERE role = "student"'
        );
        
        // Get total number of quiz attempts
        const [attemptCount] = await db.query('SELECT COUNT(*) as total FROM results');
        
        // Get recent quiz attempts (last 5)
        const [recentAttempts] = await db.query(`
            SELECT r.*, u.name as student_name, q.title as quiz_title
            FROM results r
            JOIN users u ON r.student_id = u.id
            JOIN quizzes q ON r.quiz_id = q.id
            ORDER BY r.attempted_at DESC
            LIMIT 5
        `);

        res.render('admin/dashboard', {
            user: req.session.user,
            quizCount: quizCount[0].total,
            studentCount: studentCount[0].total,
            attemptCount: attemptCount[0].total,
            recentAttempts
        });

    } catch (error) {
        console.error('Dashboard error:', error);
        res.send('Error loading dashboard');
    }
});

// =============================================
// GET /admin/quizzes - View all quizzes
// =============================================
router.get('/quizzes', async (req, res) => {
    try {
        // Get all quizzes with question count
        const [quizzes] = await db.query(`
            SELECT q.*, COUNT(qs.id) as question_count
            FROM quizzes q
            LEFT JOIN questions qs ON q.id = qs.quiz_id
            GROUP BY q.id
            ORDER BY q.created_at DESC
        `);

        res.render('admin/quizzes', { user: req.session.user, quizzes });

    } catch (error) {
        console.error('Quizzes error:', error);
        res.send('Error loading quizzes');
    }
});

// =============================================
// GET /admin/create-quiz - Show create quiz form
// =============================================
router.get('/create-quiz', (req, res) => {
    res.render('admin/create-quiz', { user: req.session.user, error: null, success: null });
});

// =============================================
// POST /admin/create-quiz - Save new quiz
// =============================================
router.post('/create-quiz', async (req, res) => {
    const { title, description, time_limit } = req.body;

    try {
        // Insert quiz into database
        const [result] = await db.query(
            'INSERT INTO quizzes (title, description, time_limit, created_by) VALUES (?, ?, ?, ?)',
            [title, description, time_limit, req.session.user.id]
        );

        // Redirect to add questions for this new quiz
        res.redirect(`/admin/add-questions/${result.insertId}`);

    } catch (error) {
        console.error('Create quiz error:', error);
        res.render('admin/create-quiz', { 
            user: req.session.user, 
            error: 'Failed to create quiz. Try again.',
            success: null
        });
    }
});

// =============================================
// GET /admin/add-questions/:quizId - Show add questions form
// =============================================
router.get('/add-questions/:quizId', async (req, res) => {
    const quizId = req.params.quizId; // Get quiz ID from URL

    try {
        // Get quiz info
        const [quizzes] = await db.query('SELECT * FROM quizzes WHERE id = ?', [quizId]);
        
        if (quizzes.length === 0) {
            return res.send('Quiz not found!');
        }

        // Get existing questions for this quiz
        const [questions] = await db.query(
            'SELECT * FROM questions WHERE quiz_id = ?', 
            [quizId]
        );

        res.render('admin/add-questions', {
            user: req.session.user,
            quiz: quizzes[0],
            questions,
            error: null,
            success: null
        });

    } catch (error) {
        console.error('Add questions error:', error);
        res.send('Error loading page');
    }
});

// =============================================
// POST /admin/add-questions/:quizId - Save a question
// =============================================
router.post('/add-questions/:quizId', async (req, res) => {
    const quizId = req.params.quizId;
    const { question_text, option_a, option_b, option_c, option_d, correct_answer } = req.body;

    try {
        // Insert question into database
        await db.query(
            `INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer) 
             VALUES (?, ?, ?, ?, ?, ?, ?)`,
            [quizId, question_text, option_a, option_b, option_c, option_d, correct_answer]
        );

        // Redirect back to add more questions
        res.redirect(`/admin/add-questions/${quizId}?added=true`);

    } catch (error) {
        console.error('Save question error:', error);
        res.redirect(`/admin/add-questions/${quizId}?error=true`);
    }
});

// =============================================
// GET /admin/delete-quiz/:id - Delete a quiz
// =============================================
router.get('/delete-quiz/:id', async (req, res) => {
    try {
        // Delete quiz (questions are auto-deleted due to CASCADE in database)
        await db.query('DELETE FROM quizzes WHERE id = ?', [req.params.id]);
        res.redirect('/admin/quizzes');
    } catch (error) {
        console.error('Delete quiz error:', error);
        res.send('Error deleting quiz');
    }
});

// =============================================
// GET /admin/delete-question/:id - Delete a question
// =============================================
router.get('/delete-question/:id', async (req, res) => {
    try {
        // Get quiz_id first so we can redirect back
        const [questions] = await db.query(
            'SELECT quiz_id FROM questions WHERE id = ?', 
            [req.params.id]
        );
        
        if (questions.length === 0) return res.send('Question not found');
        
        const quizId = questions[0].quiz_id;
        
        await db.query('DELETE FROM questions WHERE id = ?', [req.params.id]);
        res.redirect(`/admin/add-questions/${quizId}`);
        
    } catch (error) {
        console.error('Delete question error:', error);
        res.send('Error deleting question');
    }
});

// =============================================
// GET /admin/results - View all student results
// =============================================
router.get('/results', async (req, res) => {
    try {
        // Get all results with student name and quiz title
        const [results] = await db.query(`
            SELECT r.*, u.name as student_name, q.title as quiz_title
            FROM results r
            JOIN users u ON r.student_id = u.id
            JOIN quizzes q ON r.quiz_id = q.id
            ORDER BY r.attempted_at DESC
        `);

        res.render('admin/results', { user: req.session.user, results });

    } catch (error) {
        console.error('Results error:', error);
        res.send('Error loading results');
    }
});

module.exports = router;
