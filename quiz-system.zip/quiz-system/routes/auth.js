// =============================================
// routes/auth.js
// Handles: Login, Register, Logout
// =============================================

const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs'); // For password hashing
const db = require('../config/database');

// =============================================
// GET /login - Show the login page
// =============================================
router.get('/login', (req, res) => {
    // If user is already logged in, redirect them
    if (req.session.user) {
        return redirectToDashboard(req, res);
    }
    // Otherwise show login page (pass empty error message)
    res.render('login', { error: null });
});

// =============================================
// POST /login - Process the login form
// =============================================
router.post('/login', async (req, res) => {
    // Get email and password from the form
    const { email, password } = req.body;

    try {
        // Step 1: Find user in database by email
        // The ? is a placeholder - prevents SQL injection attacks
        const [users] = await db.query(
            'SELECT * FROM users WHERE email = ?', 
            [email]
        );

        // Step 2: Check if user exists
        if (users.length === 0) {
            return res.render('login', { error: 'Invalid email or password' });
        }

        const user = users[0]; // Get the first (only) result

        // Step 3: Check if password is correct
        // bcrypt.compare checks plain password against hashed one in database
        const passwordMatch = await bcrypt.compare(password, user.password);
        
        if (!passwordMatch) {
            return res.render('login', { error: 'Invalid email or password' });
        }

        // Step 4: Save user info in session (this "logs them in")
        req.session.user = {
            id: user.id,
            name: user.name,
            email: user.email,
            role: user.role
        };

        // Step 5: Redirect to their dashboard based on role
        redirectToDashboard(req, res);

    } catch (error) {
        console.error('Login error:', error);
        res.render('login', { error: 'Something went wrong. Please try again.' });
    }
});

// =============================================
// GET /register - Show the registration page
// =============================================
router.get('/register', (req, res) => {
    if (req.session.user) {
        return redirectToDashboard(req, res);
    }
    res.render('register', { error: null });
});

// =============================================
// POST /register - Process the registration form
// =============================================
router.post('/register', async (req, res) => {
    const { name, email, password, confirmPassword } = req.body;

    // Basic validation
    if (password !== confirmPassword) {
        return res.render('register', { error: 'Passwords do not match!' });
    }

    if (password.length < 6) {
        return res.render('register', { error: 'Password must be at least 6 characters!' });
    }

    try {
        // Step 1: Check if email already exists
        const [existing] = await db.query(
            'SELECT id FROM users WHERE email = ?', 
            [email]
        );

        if (existing.length > 0) {
            return res.render('register', { error: 'Email already registered!' });
        }

        // Step 2: Hash the password before saving
        // NEVER save plain text passwords!
        // "10" is the salt rounds - higher = more secure but slower
        const hashedPassword = await bcrypt.hash(password, 10);

        // Step 3: Save new user to database
        await db.query(
            'INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)',
            [name, email, hashedPassword, 'student'] // New users are always students
        );

        // Step 4: Redirect to login with success message
        res.redirect('/login?registered=true');

    } catch (error) {
        console.error('Register error:', error);
        res.render('register', { error: 'Registration failed. Please try again.' });
    }
});

// =============================================
// GET /logout - Log the user out
// =============================================
router.get('/logout', (req, res) => {
    // Destroy the session (removes all saved login data)
    req.session.destroy((err) => {
        if (err) console.error('Logout error:', err);
        res.redirect('/login');
    });
});

// ---- HELPER FUNCTION ----
// Redirects user to correct dashboard based on their role
function redirectToDashboard(req, res) {
    if (req.session.user.role === 'admin') {
        res.redirect('/admin/dashboard');
    } else {
        res.redirect('/student/dashboard');
    }
}

module.exports = router;
