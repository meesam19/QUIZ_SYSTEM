# 🎓 Smart Online Quiz & Assessment System

A beginner-friendly full-stack web app built with **Node.js**, **Express**, **MySQL**, and **EJS**.

---

## 📁 Project Structure

```
quiz-system/
│
├── server.js              ← Main file (start here!)
├── package.json           ← Project info & dependencies
├── .env                   ← Your secret settings (passwords etc.)
├── database.sql           ← Run this once to set up your database
│
├── config/
│   └── database.js        ← Connects app to MySQL
│
├── middleware/
│   └── auth.js            ← Protects pages from unauthorized access
│
├── routes/
│   ├── auth.js            ← Login, Register, Logout
│   ├── admin.js           ← All admin pages
│   └── student.js         ← All student pages
│
├── views/                 ← HTML templates (EJS files)
│   ├── login.ejs
│   ├── register.ejs
│   ├── partials/
│   │   ├── header.ejs
│   │   └── footer.ejs
│   ├── admin/
│   │   ├── dashboard.ejs
│   │   ├── quizzes.ejs
│   │   ├── create-quiz.ejs
│   │   ├── add-questions.ejs
│   │   └── results.ejs
│   └── student/
│       ├── dashboard.ejs
│       ├── attempt-quiz.ejs
│       ├── results.ejs
│       └── my-results.ejs
│
└── public/                ← Static files (CSS, JS, images)
    ├── css/
    │   └── style.css
    └── js/
        └── main.js
```

---

## ✅ Step-by-Step Setup Guide (For Beginners)

### STEP 1 — Install Required Software

Before starting, you need to install these tools:

**1. Node.js** (runs JavaScript outside the browser)
- Go to: https://nodejs.org
- Download the **LTS version** (recommended)
- Install it (just click Next, Next, Finish)
- To verify: Open Command Prompt/Terminal and type:
  ```
  node --version
  ```
  You should see something like: `v20.0.0`

**2. MySQL** (the database)
- Go to: https://dev.mysql.com/downloads/installer/
- Download **MySQL Community Installer**
- During setup, choose **Developer Default**
- Set a **root password** — remember this! You'll need it later.
- To verify: Open **MySQL Workbench** or **MySQL Command Line**

**3. Visual Studio Code** (code editor — optional but recommended)
- Go to: https://code.visualstudio.com
- Download and install

---

### STEP 2 — Download / Get the Project Files

If you have the project folder already, just open it.

Or open **Command Prompt / Terminal** and navigate to where you want the project:
```bash
cd Desktop
```

---

### STEP 3 — Install Project Dependencies

Open the project folder in **Command Prompt / Terminal**:
```bash
cd quiz-system
```

Now install all required packages (this reads package.json and downloads everything):
```bash
npm install
```

⏳ Wait for it to finish. You'll see a `node_modules` folder appear.

---

### STEP 4 — Set Up the Database

**Open MySQL** (using MySQL Workbench, MySQL Command Line, or XAMPP):

**Option A — Using MySQL Command Line:**
```bash
mysql -u root -p
```
Enter your MySQL password when asked. Then:
```sql
source C:/path/to/your/project/quiz-system/database.sql
```
(Replace the path with your actual project location)

**Option B — Using MySQL Workbench:**
1. Open MySQL Workbench
2. Connect to your local database
3. Click **File → Open SQL Script**
4. Open the `database.sql` file from the project folder
5. Click the ⚡ (Execute) button

This will create:
- The `quiz_system` database
- All 5 tables (users, quizzes, questions, results, student_answers)
- A sample admin account and test quiz

---

### STEP 5 — Configure Your Settings

Open the `.env` file in your project folder.
Change these lines to match your setup:

```
DB_HOST=localhost
DB_USER=root
DB_PASSWORD=Andleebsql* ← Change this!
DB_NAME=quiz_system
SESSION_SECRET=Secretkey12   ← Change to anything random
PORT=3000
```

Save the file.

---

### STEP 6 — Run the Application!

In Command Prompt / Terminal (make sure you're in the quiz-system folder):

**For normal start:**
```bash
npm start
```

**For development (auto-restarts when you change code):**
```bash
npm run dev
```

You should see:
```
=============================================
✅ Server is running!
🌐 Open your browser and go to:
   http://localhost:3000
=============================================
📧 Default admin login:
   Email: admin@quiz.com
   Password: admin123
=============================================
```

---

### STEP 7 — Open in Browser

Go to: **http://localhost:3000**

You'll see the login page!

---

## 🔑 Login Credentials

### Admin Account (pre-created):
- **Email:** admin@quiz.com
- **Password:** admin123

### Student Account:
- Register a new account at `/register`
- New accounts are automatically students

---

## 🚀 How to Use the System

### As an Admin:
1. Login with admin credentials
2. Go to **Create Quiz** → Fill in title, description, time limit
3. Add questions with 4 options and mark the correct answer
4. Students can now attempt the quiz
5. View student performance in **View Results**

### As a Student:
1. Register a new account at `/register`
2. Login with your new account
3. Browse available quizzes on the dashboard
4. Click **Start Quiz** to attempt
5. Answer all questions before the timer runs out
6. Submit and see your score instantly!
7. Review which questions you got right/wrong

---

## 🛠️ Common Errors & Fixes

### ❌ Error: "Cannot connect to MySQL"
**Fix:** 
- Make sure MySQL server is running
- Check your `.env` file — password must match your MySQL root password
- Try: `DB_HOST=127.0.0.1` instead of `localhost`

### ❌ Error: "Module not found"
**Fix:**
```bash
npm install
```
(Run this in the project folder)

### ❌ Error: "Port 3000 already in use"
**Fix:** Change the port in `.env`:
```
PORT=3001
```
Then go to: http://localhost:3001

### ❌ Error: "Table doesn't exist"
**Fix:** You haven't run the database setup yet. Go back to **Step 4**.

### ❌ White page / Views not loading
**Fix:** Make sure you have the `views` folder with all `.ejs` files and the `ejs` package is installed. Run `npm install` again.

---

## 📚 Technologies Explained (For Beginners)

| Technology | What it does |
|---|---|
| **Node.js** | Runs JavaScript on the server (your computer), not the browser |
| **Express.js** | A framework that makes building web servers easy in Node.js |
| **MySQL** | Database to store users, quizzes, questions, and results |
| **EJS** | Template engine — lets you mix HTML with JavaScript to show dynamic data |
| **bcryptjs** | Hashes (scrambles) passwords so they're safe to store |
| **express-session** | Remembers who is logged in between page loads |
| **dotenv** | Loads settings from `.env` file safely |

---

## 🔒 Security Features Included

- ✅ Passwords are **hashed** (never stored as plain text)
- ✅ SQL queries use **parameterized statements** (prevents SQL injection)
- ✅ Pages are **protected** — students can't access admin pages
- ✅ Sessions expire after **2 hours** automatically
- ✅ Delete confirmations prevent accidental data loss

---

## 🎯 Features Summary

### Admin Features:
- Create quizzes with title, description, and time limit
- Add unlimited MCQ questions with 4 options
- Delete quizzes and questions
- View all student results with grades
- Dashboard with statistics

### Student Features:
- Register and login securely
- Browse available quizzes
- Countdown timer during quiz
- Auto-submit when time expires
- Instant results after submission
- Detailed answer review (see what was right/wrong)
- History of all past attempts

---

## 💡 Tips for Beginners

1. **Read the comments** in every file — they explain what each line does
2. **Start the server** and open the browser to see changes
3. **Use `npm run dev`** during development so the server restarts automatically
4. **Check the terminal** for error messages if something goes wrong
5. **MySQL Workbench** is great for visually viewing your database tables

---

*Built with ❤️ for learning full-stack web development*
