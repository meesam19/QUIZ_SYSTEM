-- =============================================
-- DATABASE SETUP FILE
-- Run this file once to create all tables
-- =============================================
-- How to run: Open MySQL and type:
--   source path/to/this/file/database.sql
-- =============================================

-- Step 1: Create the database
CREATE DATABASE IF NOT EXISTS quiz_system;

-- Step 2: Use the database
USE quiz_system;

-- =============================================
-- TABLE 1: Users (stores all accounts)
-- =============================================
CREATE TABLE IF NOT EXISTS users (
    id INT AUTO_INCREMENT PRIMARY KEY,   -- Unique ID for each user
    name VARCHAR(100) NOT NULL,          -- Full name
    email VARCHAR(100) NOT NULL UNIQUE,  -- Email (must be unique)
    password VARCHAR(255) NOT NULL,      -- Hashed password (never store plain text!)
    role ENUM('admin', 'student') DEFAULT 'student',  -- User type
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP    -- When account was created
);

-- =============================================
-- TABLE 2: Quizzes (stores quiz info)
-- =============================================
CREATE TABLE IF NOT EXISTS quizzes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(200) NOT NULL,         -- Quiz name e.g. "Math Chapter 1"
    description TEXT,                    -- Short description of the quiz
    time_limit INT DEFAULT 10,           -- Time in minutes to complete quiz
    created_by INT,                      -- Which admin created this quiz
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (created_by) REFERENCES users(id)  -- Links to users table
);

-- =============================================
-- TABLE 3: Questions (stores quiz questions)
-- =============================================
CREATE TABLE IF NOT EXISTS questions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    quiz_id INT NOT NULL,                -- Which quiz this question belongs to
    question_text TEXT NOT NULL,         -- The actual question
    option_a VARCHAR(255) NOT NULL,      -- Option A
    option_b VARCHAR(255) NOT NULL,      -- Option B
    option_c VARCHAR(255) NOT NULL,      -- Option C
    option_d VARCHAR(255) NOT NULL,      -- Option D
    correct_answer CHAR(1) NOT NULL,     -- Correct answer: 'a', 'b', 'c', or 'd'
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id) ON DELETE CASCADE
);

-- =============================================
-- TABLE 4: Results (stores student scores)
-- =============================================
CREATE TABLE IF NOT EXISTS results (
    id INT AUTO_INCREMENT PRIMARY KEY,
    student_id INT NOT NULL,             -- Which student took the quiz
    quiz_id INT NOT NULL,                -- Which quiz was taken
    score INT NOT NULL,                  -- Number of correct answers
    total INT NOT NULL,                  -- Total number of questions
    percentage DECIMAL(5,2),            -- Score as a percentage
    attempted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES users(id),
    FOREIGN KEY (quiz_id) REFERENCES quizzes(id)
);

-- =============================================
-- TABLE 5: Student Answers (stores each answer)
-- =============================================
CREATE TABLE IF NOT EXISTS student_answers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    result_id INT NOT NULL,              -- Links to results table
    question_id INT NOT NULL,            -- Which question was answered
    selected_answer CHAR(1),             -- What the student chose
    is_correct BOOLEAN,                  -- Was it correct?
    FOREIGN KEY (result_id) REFERENCES results(id),
    FOREIGN KEY (question_id) REFERENCES questions(id)
);

-- =============================================
-- SAMPLE DATA - Admin Account
-- Password is: admin123
-- =============================================
INSERT INTO users (name, email, password, role) VALUES
('Admin Teacher', 'admin@quiz.com', '$2a$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');

-- =============================================
-- SAMPLE QUIZ DATA (optional, for testing)
-- =============================================
INSERT INTO quizzes (title, description, time_limit, created_by) VALUES
('JavaScript Basics', 'Test your basic JavaScript knowledge', 10, 1);

INSERT INTO questions (quiz_id, question_text, option_a, option_b, option_c, option_d, correct_answer) VALUES
(1, 'What does HTML stand for?', 
 'Hyper Text Markup Language', 
 'High Tech Modern Language', 
 'Hyper Transfer Markup Language', 
 'Home Tool Markup Language', 
 'a'),
(1, 'Which keyword declares a variable in JavaScript?', 
 'var', 
 'let', 
 'const', 
 'All of the above', 
 'd'),
(1, 'What is the correct way to write a comment in JavaScript?', 
 '<!-- comment -->', 
 '// comment', 
 '** comment **', 
 '## comment', 
 'b');



