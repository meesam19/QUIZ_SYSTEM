// =============================================
// public/js/main.js
// Client-side JavaScript (runs in the browser)
// =============================================

// ---- Wait for page to fully load before running anything ----
document.addEventListener('DOMContentLoaded', function() {

    // =============================================
    // AUTO-HIDE ALERT MESSAGES after 4 seconds
    // =============================================
    const alerts = document.querySelectorAll('.alert');
    alerts.forEach(function(alert) {
        setTimeout(function() {
            alert.style.transition = 'opacity 0.5s';
            alert.style.opacity = '0';
            // Remove from DOM after fade out
            setTimeout(function() {
                alert.remove();
            }, 500);
        }, 4000); // 4000ms = 4 seconds
    });

    // =============================================
    // CONFIRM PASSWORD VALIDATION on Register Page
    // =============================================
    const passwordInput = document.getElementById('password');
    const confirmInput = document.getElementById('confirmPassword');

    if (passwordInput && confirmInput) {
        confirmInput.addEventListener('input', function() {
            if (confirmInput.value !== passwordInput.value) {
                confirmInput.setCustomValidity('Passwords do not match!');
                confirmInput.style.borderColor = '#dc2626';
            } else {
                confirmInput.setCustomValidity(''); // Clear error
                confirmInput.style.borderColor = '#16a34a';
            }
        });
    }

    // =============================================
    // ACTIVE NAV LINK - Highlight current page
    // =============================================
    // Get the current URL path
    const currentPath = window.location.pathname;
    
    // Find all sidebar links
    const navLinks = document.querySelectorAll('.sidebar-menu a');
    
    navLinks.forEach(function(link) {
        // If the link's href matches current page, add 'active' class
        if (link.getAttribute('href') === currentPath) {
            link.classList.add('active');
        }
    });

    // =============================================
    // QUESTION PROGRESS TRACKER on Quiz Page
    // =============================================
    const radioButtons = document.querySelectorAll('.option-radio');
    
    if (radioButtons.length > 0) {
        // Update progress when any answer is selected
        radioButtons.forEach(function(radio) {
            radio.addEventListener('change', updateProgress);
        });
    }

    function updateProgress() {
        const totalQuestions = document.querySelectorAll('.question-block').length;
        // Count how many questions have been answered
        const answered = new Set();
        document.querySelectorAll('.option-radio:checked').forEach(function(radio) {
            answered.add(radio.name); // radio name = question id
        });
        
        const answeredCount = answered.size;
        
        // Update the browser tab title to show progress
        document.title = `(${answeredCount}/${totalQuestions}) QuizMaster`;
    }

    // =============================================
    // SMOOTH SCROLL TO TOP UTILITY
    // =============================================
    // Add this class to any element to scroll to top on click: class="scroll-top"
    const scrollTopBtns = document.querySelectorAll('.scroll-top');
    scrollTopBtns.forEach(function(btn) {
        btn.addEventListener('click', function() {
            window.scrollTo({ top: 0, behavior: 'smooth' });
        });
    });

});
