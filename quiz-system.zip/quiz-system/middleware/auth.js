// =============================================
// middleware/auth.js
// These functions protect pages from unauthorized access
// =============================================

// ---- Middleware: Check if user is logged in ----
// Used on ALL protected pages
function isLoggedIn(req, res, next) {
    if (req.session.user) {
        next(); // User is logged in, allow access
    } else {
        res.redirect('/login'); // Not logged in, go to login page
    }
}

// ---- Middleware: Check if user is an Admin ----
// Used on Admin-only pages
function isAdmin(req, res, next) {
    if (req.session.user && req.session.user.role === 'admin') {
        next(); // Is admin, allow access
    } else {
        res.status(403).send('Access Denied. Admins only!');
    }
}

// ---- Middleware: Check if user is a Student ----
// Used on Student-only pages
function isStudent(req, res, next) {
    if (req.session.user && req.session.user.role === 'student') {
        next(); // Is student, allow access
    } else {
        res.status(403).send('Access Denied. Students only!');
    }
}

module.exports = { isLoggedIn, isAdmin, isStudent };
